
import { useState } from 'react';
import { calculateLease } from '../utils/leaseCalc';

export default function Calculator() {
  const [zip, setZip] = useState('');
  const [brand, setBrand] = useState('BMW');
  const [model, setModel] = useState('');
  const [msrp, setMsrp] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [term, setTerm] = useState(36);
  const [mileage, setMileage] = useState(10000);
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const lease = calculateLease({ zip, brand, model, msrp, sellingPrice, term, mileage });
    setResult(lease);
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Lease Calculator</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="ZIP Code" value={zip} onChange={(e) => setZip(e.target.value)} required /><br />
        <input placeholder="Brand (e.g. BMW)" value={brand} onChange={(e) => setBrand(e.target.value)} /><br />
        <input placeholder="Model" value={model} onChange={(e) => setModel(e.target.value)} /><br />
        <input placeholder="MSRP" value={msrp} onChange={(e) => setMsrp(e.target.value)} /><br />
        <input placeholder="Selling Price" value={sellingPrice} onChange={(e) => setSellingPrice(e.target.value)} /><br />
        <input placeholder="Term (months)" value={term} onChange={(e) => setTerm(e.target.value)} /><br />
        <input placeholder="Mileage/year" value={mileage} onChange={(e) => setMileage(e.target.value)} /><br />
        <button type="submit">Calculate</button>
      </form>
      {result && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Monthly Payment: ${result.monthly}</h3>
          <p>Residual: ${result.residual}</p>
          <p>Money Factor: {result.mf}</p>
          <p>Total Due at Signing: ${result.das}</p>
        </div>
      )}
    </div>
  );
}

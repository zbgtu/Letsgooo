
export default function Home() {
  return (
    <main style={{ padding: "3rem" }}>
      <h1>🚗 Letsgooo — VIN Inventory Portal</h1>
      <p>This site is live and connected to Firebase. Dealer and demo inventory data is next.</p>
    </main>
  );
}

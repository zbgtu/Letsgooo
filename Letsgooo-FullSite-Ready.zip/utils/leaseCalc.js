
export function calculateLease({ zip, brand, model, msrp, sellingPrice, term, mileage }) {
  const mf = 0.0025;
  const residualPercent = 0.58;
  const docFee = 495;
  const acqFee = 895;
  const taxRate = 0.07;

  const capCost = parseFloat(sellingPrice) + docFee + acqFee;
  const residual = parseFloat(msrp) * residualPercent;
  const depreciation = capCost - residual;
  const rentCharge = (capCost + residual) * mf;
  const baseMonthly = (depreciation + rentCharge) / term;
  const taxAmount = baseMonthly * taxRate;
  const monthly = (baseMonthly + taxAmount).toFixed(2);
  const das = (baseMonthly + taxAmount + docFee + acqFee).toFixed(2);

  return {
    monthly,
    residual: residual.toFixed(2),
    mf,
    das
  };
}
